Sys.setenv("R_TESTS" = "")
library(testthat)
library(qicharts2)

test_check("qicharts2")
