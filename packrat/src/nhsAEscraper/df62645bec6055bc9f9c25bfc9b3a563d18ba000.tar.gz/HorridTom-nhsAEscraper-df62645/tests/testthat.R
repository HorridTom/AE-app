library(testthat)
library(nhsAEscraper)

test_check("nhsAEscraper")
